import UIKit

class car
{
    var option1: String = "Engine"
    var option2: String = "interior"
    var option3: String = "color"
    var option4: String = "wheels"

    func caroptions(option1: String, option2: String, option3: String, option4: String)-> String {
    return option1 + option2 + option3 + option4
    }
}

var parts = car()

var GTR = parts.caroptions(option1: "Engine \n ", option2: "interior \n", option3: "color \n", option4: "wheels \n")
print(GTR)
